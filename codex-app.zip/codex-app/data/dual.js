window.CODEX_DATA = window.CODEX_DATA || {};
window.CODEX_DATA.dual = ({cd,rw,sh}) => {
const c='#e879f9';
return sh('DUAL AWAKENED',c)+
cd('DUAL AWAKENING','c','<p style="color:#9b91c4;font-size:13px;line-height:1.6;margin:0">Both Mana Hall and Ki Core are active. Growth is split. Synergy unlocks only after True Core / Master stage.</p>').replace('c',c)+
`<div style="margin-top:10px;display:grid;grid-template-columns:1fr 1fr;gap:10px">`+
cd('GROWTH PENALTY','#ef4444',rw('Until True Core/Master','50% slower in both systems','#ef4444')+rw('After True Core/Master','Synergy unlocks','#34d399'))+
cd('COMBAT CONFLICT','#ef4444','<p style="color:#9b91c4;font-size:12px;margin:0;line-height:1.5">Cannot use <span style="color:#818cf8">Incantation</span> + <span style="color:#f97316">Form Casting</span> simultaneously.<br><br>Exception: Temperance blessing OR Saint+/Grandmaster+ control.</p>')+
cd('ALLOWED COMBOS',c,rw('Quick + Flash','2x resource cost',c)+rw('Silent + Still','2x resource cost',c))+
cd('SYNERGY ARTS','#34d399',['Spellblade','Ki-Mana Armor','Domain Fusion'].map(s=>`<div style="color:#34d399;font-family:monospace;font-size:13px;padding:4px 0;border-bottom:1px solid rgba(255,255,255,.05)">${s}</div>`).join(''))+
`</div><div style="margin-top:10px">`+
cd('PEAK CAP',c,'<p style="color:#9b91c4;font-size:12px;margin:0;line-height:1.5"><span style="color:#e879f9">Heaven-Opening Realm / Sovereign Archon Stage</span> = strongest mortal tier. Only <span style="color:#fbbf24">2-3 in recorded history</span> reached this as dual-awakened.</p>')+
'</div>';
};
