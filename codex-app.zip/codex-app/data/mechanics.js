window.CODEX_DATA = window.CODEX_DATA || {};
window.CODEX_DATA.mechanics = ({cd,rw,pl,ib,sh,stabs}) => {
const DMG=[
{n:'Pathway Scorch',c:'#818cf8',sub:'Magic overdraw / Light vs Duskwalker / extra Fleshscript. Recovery = base x0.5 to x3.0.',rows:[['Adept/Expert (natural)','~1 month'],['Adept/Expert + Aetherium','~10 days'],['Master (natural)','~6 months'],['Master + Aetherium','~2 months'],['Grandmaster (natural)','~2 years'],['Grandmaster + Aetherium','~8 months'],['Archmage+','Permanent (80%). Worldroot + Saint healer = 5yr for 20%']]},
{n:'Meridian Damage',c:'#f97316',sub:'Ki overdraw / break Form mid-Edict / open Gate 3+. -50% max ki. Random Art 50% fail 1 month.',rows:[['Adept/Refined','~1 month'],['Expert/Tempered','~6 months'],['Grandmaster+','Death or crippled 90%']]},
{n:'Oathbacklash',c:'#ef4444',sub:'Break an Oathslate contract.',rows:[['Mechanical','Pathway Scorch + Meridian Damage simultaneously. -80% both pools 1 month.'],['Social','Permanent Oathbreaker brand. Future Oathslates crack at touch.'],['Clean Break','Law Spell: I deny this oath - costs caster 10 years lifespan.']]},
{n:'Script Fever',c:'#a78bfa',sub:'Holding 4+ active Fleshscripts simultaneously.',rows:[['Effect','-5% max pool per extra script, permanent.'],['Removal','Remove scripts surgically - stat loss stays.']]},
{n:'Tenketsu Scorch',c:'#f97316',sub:'Tenketsu forced shut.',rows:[['Effect','-10% ki output per 36 closed.'],['Recovery','1 week per 36, or healing art.']]},
{n:'Resonance Cascade',c:'#e879f9',sub:'5% chance when Prism uses 3+ elements at once.',rows:[['Effect','Elements fuse into new derivative permanently.'],['Control','Cannot be controlled or predicted.']]},
{n:'Leyline Boost',c:'#34d399',sub:'Passive bonus when standing on a leyline.',rows:[['All spells/arts','-30% cost'],['Royal spirit on leyline','War/Siege spells cast for free']]},
];
const LRN=[['Tutelage','Fastest','Direct from master or manual. 1-6 months for Combat/Flow tier.'],['Spell Tomes / Art Scrolls','3x slower','10% mislearn = Pathway Scorch or Meridian Damage.'],['Observation','Quick/Flash only','-30% power until mastered. Eye Pact = instant mastery.'],['Spirit Teaching','5x faster',"Only works for the spirit's own element."]];
return sh('MECHANICS','#ef4444')+stabs('mec',[['dm','Damage States'],['an','Anti-Magic/Ki'],['lr','Learning'],['it','Items']],'#ef4444')+
'<div id="mec-dm" class="sub on"><div class="fc">'+DMG.map(d=>cd(d.n,d.c,'<p style="color:#4a4570;font-size:11px;margin:0 0 7px">'+d.sub+'</p>'+d.rows.map(([l,v])=>rw(l,v)).join(''))).join('')+'</div></div>'+
'<div id="mec-an" class="sub"><div class="g" style="grid-template-columns:1fr 1fr;gap:10px">'+
cd('NULLSTONE','#ef4444',rw('Effect','Complete mana/ki block. Dead zone 1-10m radius.')+rw('Cancels','Cold Iron -80% drain - choose block vs drain, not both.')+rw('Escape','Pure brute force only.'))+
cd('COLD IRON','#ef4444',rw('Effect','-80% mana/ki flow. Very durable. Burns spirits/beasts.')+rw('Poisoning','Worn 1hr: -85% current, -5% max pool. Worn 10hr: -80% current, -50% max. Remove + 1 day = 100% recovery.')+rw('Escape','Saint Realm / Grand Archmage brute force.')+rw('Inside Nullstone','Just durable metal.'))+
'</div></div>'+
'<div id="mec-lr" class="sub"><div class="fc">'+
cd('LEARNING EXISTING ARTS/SPELLS','#818cf8',LRN.map(([m,sp,d])=>'<div style="padding:6px 0;border-bottom:1px solid rgba(255,255,255,.05)"><div style="display:flex;gap:8px;margin-bottom:2px"><span style="color:#818cf8;font-family:monospace;font-size:12px;min-width:160px">'+m+'</span><span style="color:#fbbf24;font-size:11px">'+sp+'</span></div><div style="color:#4a4570;font-size:11px">'+d+'</div></div>').join('')+'<p style="color:#ef4444;font-size:11px;margin-top:8px">Rank Gate enforced - cannot learn/cast above current stage.</p>')+
cd('CREATING NEW ARTS/SPELLS','#f97316',[['Requirement','Must have all elements/aspects involved'],['Spark/Pulse','Weeks'],['Combat/Flow','Months, 100+ test casts'],['War/Surge','Years'],['Siege/Manifest+','Team + lifetime']].map(([l,v])=>rw(l,v)).join('')+'<div style="margin-top:9px"><div style="color:#4a4570;font-size:11px;font-family:monospace;margin-bottom:4px">CREATION METHODS</div>'+['Derivative fusion','Principle derivation','Spirit co-creation','Inspiration trauma'].map(m=>pl(m,'#f97316')).join('')+'</div>')+
'</div></div>'+
'<div id="mec-it" class="sub"><div class="g" style="grid-template-columns:1fr 1fr;gap:10px">'+
cd('MUNDANE FOCI / STAVES / ROBES','#4a4570','<p style="color:#9b91c4;font-size:12px;margin:0">Preference only. <span style="color:#ef4444">No mechanical boost.</span></p>')+
cd('ARTIFACTS & RELICS','#fbbf24','<p style="color:#9b91c4;font-size:12px;margin:0;line-height:1.5">Can grant: <span style="color:#fbbf24">-30% cost, Auto-Silent Casting, unique techniques.</span><br>Tracked by factions. Fought over. Relic pacts possible.</p>')+
'</div></div>';
};