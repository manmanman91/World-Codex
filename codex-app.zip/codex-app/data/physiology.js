window.CODEX_DATA = window.CODEX_DATA || {};
window.CODEX_DATA.physiology = ({cd,rw,pl,ib,sh,stabs,rtbl}) => {
const organs=[
  ['◈ Mana Hall','#818cf8','Magic','Pathway Scorch','Stores raw mana. Size at birth = talent cap. Expands slowly with training.'],
  ['≋ Mana Pathways','#818cf8','Magic','Pathway Scorch','Veins for mana. Width and flow rate determine casting speed and power throughput.'],
  ['◉ Ki Core','#f97316','Ki','Meridian Damage','Dense center in lower dantian. Stores refined ki/life energy. Grows via breath arts and body tempering.'],
  ['⟁ Meridian Channels','#f97316','Ki','Meridian Damage','Network for ki circulation. Governs body enhancement. Blockage causes Meridian Damage.'],
  ['◎ Tenketsu Points','#f97316','Ki','Tenketsu Scorch','361 nodes on the body where ki can be expelled. Closed by default. Open via training to use external ki constructs — clones, elemental shaping, puppet strings. Opening 1 tenketsu permanently costs 0.1% max ki pool. Opening all 361 = −36.1% pool. Counters: pressure point arts, Cold Iron needles pin shut 1hr.'],
];
return sh('PHYSIOLOGY','#9b91c4')+
'<p style="color:#9b91c4;font-size:13px;margin-bottom:14px;line-height:1.6">Every living being is born with five internal organs governing power. Magic and Ki are <em>separate systems</em>.</p>'+
'<div class="g g2">'+organs.map(([name,c,sys,dmg,desc])=>cd(name,c,
  `<p style="color:#ddd6f3;font-size:12px;line-height:1.6;margin:0 0 7px">${desc}</p>`+
  `<span class="tag" style="border:1px solid color-mix(in srgb,${c} 38%,transparent);background:color-mix(in srgb,${c} 14%,transparent);color:${c}">${sys}</span>`+
  `<span class="tag" style="border:1px solid rgba(239,68,68,.38);background:rgba(239,68,68,.13);color:#ef4444">Damage: ${dmg}</span>`
)).join('')+'</div>';
};
