window.CODEX_DATA = window.CODEX_DATA || {};
window.CODEX_DATA.vampires = ({cd,rw,sh}) => {
const c='#f472b6';
return sh('VAMPIRES',c)+'<div class="fc">'+
cd('OVERVIEW',c,[['Rarity','Rare and secretive. More common than angels, demons, and pure dragons.'],['Location','Hidden cities or kingdoms - not publicly known.'],['Magic','90% magic awakening. Blood converts to mana at 2:1 ratio. Tri-Blooded common.'],['Ki','10% ki awakening rate. Vampire ki users are extremely rare.'],['Weakness','Dangerous but vulnerable to exposure.']].map(([l,v])=>rw(l,v)).join(''))+
cd('HIERARCHY',c,[['Progenitors','#f87171','Oldest, rarest, strongest bloodlines. The apex of vampire society.'],['Pure Bloods',c,'Noble descendants of progenitors.'],['Regular Vampires','#4a4570','Turned vampires, mixed lines, and lesser branches.']].map(([tier,co,d])=>'<div style="padding:7px 0;border-bottom:1px solid rgba(255,255,255,.05)"><div style="color:'+co+';font-family:monospace;font-size:12px;font-weight:700;margin-bottom:2px">'+tier+'</div><div style="color:#9b91c4;font-size:12px">'+d+'</div></div>').join(''))+
'<div class="g g3">'+
cd('PROGENITOR HOUSES','#f87171',['House Nocthyr','House Velcora','House Dravane','House Veyrath','House Morlune','House Sanguivar'].map(p=>'<div style="color:#ddd6f3;font-size:12px;padding:3px 0;border-bottom:1px solid rgba(255,255,255,.04)">'+p+'</div>').join(''))+
cd('PURE BLOOD LINES',c,['Blackthorn Line','Crimson Veil Line','Nightrose Line','Silver Fang Line','Pale Court Line','Velvet Dusk Line','Roseblood Line','Moonfang Line','Thornblood Line','Duskwreath Line'].map(p=>'<div style="color:#ddd6f3;font-size:12px;padding:3px 0;border-bottom:1px solid rgba(255,255,255,.04)">'+p+'</div>').join(''))+
cd('REGULAR HOUSES','#4a4570',['House Vael','House Corven','House Drev','House Sorn','House Rhyss','House Thale','House Velin','House Marrow','House Kyrn','House Neris'].map(p=>'<div style="color:#ddd6f3;font-size:12px;padding:3px 0;border-bottom:1px solid rgba(255,255,255,.04)">'+p+'</div>').join(''))+
'</div></div>';
};