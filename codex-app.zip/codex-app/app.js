'use strict';

// ── HELPERS ──────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const h = (tag, attrs, ...children) => {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el[k] = v;
    else el.setAttribute(k, v);
  }
  children.forEach(c => {
    if (typeof c === 'string') el.innerHTML += c;
    else if (c) el.appendChild(c);
  });
  return el;
};

const cd = (title, color, body) =>
  `<div class="card" style="background:color-mix(in srgb,${color} 6%,transparent);border:1px solid color-mix(in srgb,${color} 28%,transparent)"><div class="ch" style="background:linear-gradient(90deg,color-mix(in srgb,${color} 17%,transparent),transparent);color:${color}">${title}</div><div class="cb">${body}</div></div>`;

const rw = (l, v, c = '#9b91c4') =>
  `<div class="row"><span class="rl">${l}</span><span class="rv" style="color:${c}">${v}</span></div>`;

const pl = (t, c) =>
  `<span class="pill" style="border:1px solid color-mix(in srgb,${c} 38%,transparent);background:color-mix(in srgb,${c} 13%,transparent);color:${c}">${t}</span>`;

const ib = (html, c) =>
  `<div class="ib" style="background:color-mix(in srgb,${c} 6%,transparent);border:1px solid color-mix(in srgb,${c} 23%,transparent)">${html}</div>`;

const sh = (label, c) =>
  `<div class="sl" style="color:${c}">${label}</div><div class="sb" style="background:${c}"></div>`;

const stabs = (id, tabs, c) =>
  `<div class="stabs" style="--sc:${c}">${tabs.map((t, i) =>
    `<button class="st${i === 0 ? ' on' : ''}" onclick="SS('${id}','${t[0]}',this)">${t[1]}</button>`
  ).join('')}</div>`;

const rtbl = (ranks, c) =>
  `<div style="display:grid;grid-template-columns:20px 1fr 1fr 1fr;gap:6px;padding:3px 6px 7px;border-bottom:1px solid rgba(255,255,255,.07);margin-bottom:3px">${
    ['#','Stage/Realm','Art Tier','Cost'].map(h=>`<span style="color:#4a4570;font-size:10px;font-family:monospace">${h}</span>`).join('')
  }</div>` + ranks.map(([r,a,co],i)=>
    `<div style="display:grid;grid-template-columns:20px 1fr 1fr 1fr;gap:6px;padding:5px 6px;border-radius:5px;margin-bottom:2px;border:1px solid transparent;cursor:default;transition:all .15s" onmouseenter="this.style.background='color-mix(in srgb,${c} 11%,transparent)';this.style.borderColor='color-mix(in srgb,${c} 38%,transparent)'" onmouseleave="this.style.background='';this.style.borderColor='transparent'">
      <span style="color:color-mix(in srgb,${c} 55%,transparent);font-size:10px">${i+1}</span>
      <span style="color:#ddd6f3;font-size:11px;font-weight:600">${r}</span>
      <span style="color:#4a4570;font-size:11px">${a}</span>
      <span style="color:#6b6490;font-size:11px">${co}</span>
    </div>`
  ).join('');

const matcard = m =>
  `<div class="mc" onclick="this.classList.toggle('open')">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:5px">
      <div style="color:#ddd6f3;font-family:monospace;font-size:13px;font-weight:700">${m.n}</div>
      <span style="color:${m.rc};font-size:10px;font-family:monospace;border:1px solid color-mix(in srgb,${m.rc} 38%,transparent);background:color-mix(in srgb,${m.rc} 11%,transparent);padding:2px 6px;border-radius:4px">${m.r}</span>
    </div>
    <p style="color:#9b91c4;font-size:12px;margin:0 0 6px;line-height:1.5">${m.p}</p>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;font-size:11px">
      <div><span style="color:#4a4570">Source: </span><span style="color:#9b91c4">${m.s}</span></div>
      <div><span style="color:rgba(239,68,68,.6)">Counters: </span><span style="color:#9b91c4">${m.c}</span></div>
    </div>
    <div class="mu"><div style="color:#4a4570;font-size:10px;font-family:monospace;margin-bottom:3px">USES</div><div style="color:#ddd6f3;font-size:11px;line-height:1.5">${m.u}</div></div>
    <div style="color:#4a4570;font-size:10px;text-align:right;margin-top:5px">tap to see uses</div>
  </div>`;

// ── NAV ──────────────────────────────────────────────────────────────────────
function T(id, btn) {
  document.querySelectorAll('.sec').forEach(s => s.classList.remove('on'));
  document.querySelectorAll('.nb').forEach(b => b.classList.remove('on'));
  const sec = $('s-' + id);
  if (sec) { sec.classList.add('on'); btn.classList.add('on'); }
}

function SS(tab, sub, btn) {
  document.querySelectorAll('#s-' + tab + ' .sub').forEach(s => s.classList.remove('on'));
  const el = $(tab + '-' + sub);
  if (el) el.classList.add('on');
  btn.closest('.stabs').querySelectorAll('.st').forEach(b => b.classList.remove('on'));
  btn.classList.add('on');
}

// expose globals
window.T = T;
window.SS = SS;
window.showRegion = (name) => {
  document.querySelectorAll('[id^="region-"]').forEach(d => d.style.display = 'none');
  const el = document.getElementById('region-' + name.replace(/[^a-z0-9]/gi, '_'));
  if (el) el.style.display = 'block';
};

// ── TABS CONFIG ───────────────────────────────────────────────────────────────
const TABS = [
  ['physiology','Physiology','#9b91c4'],
  ['awakening','Awakening','#fbbf24'],
  ['magic','Magic','#818cf8'],
  ['ki','Ki System','#f97316'],
  ['spirit','Spirits','#34d399'],
  ['dual','Dual Awakened','#e879f9'],
  ['mechanics','Mechanics','#ef4444'],
  ['domains','Domains','#818cf8'],
  ['world','World','#38bdf8'],
  ['pacts','Pacts','#fde68a'],
  ['arcadia','Arcadia','#34d399'],
  ['vampires','Vampires','#f472b6'],
  ['ashfall','Ashfall','#dc2626'],
  ['materials','Materials','#a78bfa'],
  ['lore','Lore & Systems','#34d399'],
  ['beastbound','Beastbound','#dc2626'],
];

// ── INIT ─────────────────────────────────────────────────────────────────────
function init() {
  const nav = $('nav');
  const con = $('con');

  // Build nav buttons
  TABS.forEach(([id, label, color], i) => {
    const btn = document.createElement('button');
    btn.className = 'nb' + (i === 0 ? ' on' : '');
    btn.style.setProperty('--c', color);
    btn.textContent = label;
    btn.onclick = () => T(id, btn);
    nav.appendChild(btn);
  });

  // Build section containers
  TABS.forEach(([id], i) => {
    const sec = document.createElement('div');
    sec.id = 's-' + id;
    sec.className = 'sec' + (i === 0 ? ' on' : '');
    con.appendChild(sec);
  });

  // Render each section from data files
  if (window.CODEX_DATA) {
    Object.entries(window.CODEX_DATA).forEach(([id, renderFn]) => {
      const sec = $('s-' + id);
      if (sec && typeof renderFn === 'function') {
        sec.innerHTML = renderFn({ cd, rw, pl, ib, sh, stabs, rtbl, matcard });
      }
    });
  }
}

document.addEventListener('DOMContentLoaded', init);
